

CREATE TABLE `bankmessags` (
  `id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `message` varchar(200) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO bankmessags VALUES("0","1","تراکنش با موفقیت انجام شد");
INSERT INTO bankmessags VALUES("11","1","شماره کارت نا معتبر است");
INSERT INTO bankmessags VALUES("12","1","موجودی کافی نیست");
INSERT INTO bankmessags VALUES("13","1","رمز نادرست است");
INSERT INTO bankmessags VALUES("14","1","تعداد دفعات وارد کردن رمز بیش از حد مجاز است");
INSERT INTO bankmessags VALUES("15","1","کارت نامعتبر است");
INSERT INTO bankmessags VALUES("16","1","دفعات برداشت وجه بیش از حد مجاز است");
INSERT INTO bankmessags VALUES("17","1","کاربر از انجام تراکنش منصرف شده است");
INSERT INTO bankmessags VALUES("18","1","تاریخ انقضای کارت گذشته است");
INSERT INTO bankmessags VALUES("19","1","مبلغ برداشت وجه بیش از حد مجاز است");
INSERT INTO bankmessags VALUES("21","1","پذیرنده نامعتبر است");
INSERT INTO bankmessags VALUES("23","1","خطای امنیتی رخ داده است");
INSERT INTO bankmessags VALUES("24","1","اطلاعات کاربری پذیرنده نا متبر است");
INSERT INTO bankmessags VALUES("25","1","مبلغ نا معتبر است");
INSERT INTO bankmessags VALUES("31","1","پاسخ نامعتبر است");
INSERT INTO bankmessags VALUES("32","1","فرمت اطلاعات وارد شده صحیح نمی باشد");
INSERT INTO bankmessags VALUES("33","1","حساب نامعتبر است");
INSERT INTO bankmessags VALUES("34","1","خطای سیستمی");
INSERT INTO bankmessags VALUES("35","1","تاریخ نامعتبر است");
INSERT INTO bankmessags VALUES("41","1","شماره درخواست تکراری است");
INSERT INTO bankmessags VALUES("42","1","تراکنش خرید یافت نشد");
INSERT INTO bankmessags VALUES("43","1","قبلا درخواست Verify داده شده است");
INSERT INTO bankmessags VALUES("44","1","درخواست Verfiy یافت نشد");
INSERT INTO bankmessags VALUES("45","1","تراکنش Settle شده است");
INSERT INTO bankmessags VALUES("46","1","تراکنش Settle نشده است");
INSERT INTO bankmessags VALUES("47","1","تراکنش Settle یافت نشد");
INSERT INTO bankmessags VALUES("48","1","تراکنش Reverse شده است");
INSERT INTO bankmessags VALUES("49","1","تراکنش Refund شده است");
INSERT INTO bankmessags VALUES("51","1","تراکنش تکراری است");
INSERT INTO bankmessags VALUES("54","1","تراکنش مرجع موجود نیست");
INSERT INTO bankmessags VALUES("55","1","تراکنش نامعتبر است");
INSERT INTO bankmessags VALUES("61","1","خطا در واریز");
INSERT INTO bankmessags VALUES("111","1","صادر کننده کارت نامعتبر است");
INSERT INTO bankmessags VALUES("112","1","خطای سویچ صادر کننده کارت");
INSERT INTO bankmessags VALUES("113","1","پاسخی از صادر  کارت دریافت نشد");
INSERT INTO bankmessags VALUES("114","1","دارنده کارت مجاز به انجام این تراکنش نیست");
INSERT INTO bankmessags VALUES("412","1","شناسه قبض نادرست است");
INSERT INTO bankmessags VALUES("413","1","شناسه پرداخت نادرست است");
INSERT INTO bankmessags VALUES("414","1","سازمان صادر کننده قبض نادرست است");
INSERT INTO bankmessags VALUES("415","1","زمان جلسه کاری به پایان رسیده است");
INSERT INTO bankmessags VALUES("416","1","خط در ثبت اطلاعات");
INSERT INTO bankmessags VALUES("417","1","شناسه پرداخت کننده نامعتبر است");
INSERT INTO bankmessags VALUES("418","1","اشکال در تعریف اطلاعات مشتری");
INSERT INTO bankmessags VALUES("419","1","تعداد دفعات ورود اطلاعات بیشتر از حد مجاز است");
INSERT INTO bankmessags VALUES("421","1","IP نامعتبر است");





CREATE TABLE `banks` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `arangment` int(11) NOT NULL,
  `active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO banks VALUES("1","درگاه بانک ملت","mellat.jpg","1","1");
INSERT INTO banks VALUES("2","درگاه بانک سامان","saman.jpg","2","0");
INSERT INTO banks VALUES("3","درگاه بانک شهر","shahr.jpg","3","0");





CREATE TABLE `discountcoupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discounttype_id` int(11) DEFAULT NULL,
  `code` varchar(100) COLLATE utf8_polish_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

INSERT INTO discountcoupons VALUES("31","4","99F4A5FEF7B45624924EB900758BE690","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("32","4","0BF1ACE74C80D5A941676918831D37E9","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("33","4","EFFBB64FF6C9B38C6FCB05185CD22FC3","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("34","4","18B67AFE27829441B0845C36BFBC30D1","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("35","4","3126ED973CBECDE2BBFFE419F139F456","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("36","4","35937E34256CF4E5B2F7DA08871D2A0B","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("37","4","4C0A5218724F1F0C224737BE2CBE8661","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("38","4","33D3B157DDC0896ADDFB22FA2A519097","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("39","4","2ADAFB1B5D684E6C15A2D063367BE012","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("40","4","060AFC8A563AACCD288F98B7C8723B61","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("41","4","7F5A17B792B687FC4C227A5C5E569DD8","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("42","4","26A307361DE9F093E261C8C94D7814C0","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("43","4","15256A6B7F55E835D0D50A20833B11BB","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("44","4","E81F1E4FE5B85BE7A6619D0B33427E01","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("45","4","586406BBB76B6BAAC45C43A81EC2E35C","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("46","4","61C68AC879A7EC23B78912AA04F59D78","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("47","4","D42F619034D73616DABDE1ED098739C2","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("48","4","601040BB131DB3D614D140F9CD43C242","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("49","4","37D7465C1CF6B226541C17D5B92034C1","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("50","4","9CA90593821A015F234E9A8195AE5582","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("51","4","870458535281D3DFCE64D423354091B1","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("52","4","74D3B2328ADADBD5C9740B050D0A333C","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("53","4","D13756F0B7ADFEB6C08B99A3EB8EBDDC","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("54","4","61C66A2F4E6E10DC9C16DDF9D19745D6","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("55","4","757BE053BAA902A28FEF53520783D4C0","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("56","4","D45959550312221E15FDE04690B18ACD","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("57","4","7EDCFB2D8F6A659EF4CD1E6C9B6D7079","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("58","4","C8AAE6E64A66C6505372D132360F72C2","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("59","4","137B7C791204FF4CCAB2A7C63462123E","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("60","4","9B47B8678D84EA8A0F9FE6C4EC599918","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("61","4","0314C9B108B8C39F1CF878ED93FDD5AE","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("62","4","973CF0F1E5CB6A86BCC5A188D698A7BC","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("63","4","6421C5810FF5713B4B9B5C25D4E44404","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("64","4","06D2CBE86D50E46350C9CFE53A7E1356","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("65","4","7B061988B655FA9F9D4FFC41D1D68160","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("66","4","AE5EB824EF87499F644C3F11A7176157","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("67","4","5E00E01A9EDA901400AF2385124A46F4","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("68","4","DF584EBB35586E6AFDDB744E9DE7236F","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("69","4","D30CFE3DECA3EC4DE141FCF9C31097A3","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("70","4","D744C4E196F729DF5FA41BCB8DF27EAB","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("71","4","FFA486A4029DEE1A46C0ED19BDC4B6B7","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("72","4","25A88A0BBEFB70A916606634C3E76DA6","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("73","4","6C49D08DBF30C9E44E3C17B1EC6EBB67","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("74","4","5C4673BCE4320DA5B54CF78055E59098","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("75","4","F516DFB84B9051ED85B89CDC3A8AB7F5","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("76","4","7612936DCC85282C6FA4DD9D4FFE57F1","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("77","4","8B4224068A41C5D37F5E2D54F3995089","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("78","4","1BF3FA859C48493F5F2606CCAAA0F20E","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("79","4","618B0FFFDFDB50766E4D51574BC4E533","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("80","4","1FF655EDAAC1CA6A033C5290110D7A55","2019-01-08 01:38:07");
INSERT INTO discountcoupons VALUES("81","4","D7A2ABC84BF1D761021324A2851E1A49","2019-01-08 01:38:07");





CREATE TABLE `discounttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci DEFAULT NULL,
  `percent` decimal(5,2) DEFAULT NULL,
  `amount` decimal(10,0) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text CHARACTER SET utf8 COLLATE utf8_persian_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

INSERT INTO discounttypes VALUES("4","بربری","10.00","","2019-01-08 01:37:56","شب یلادا");





CREATE TABLE `inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `entry_date` date NOT NULL,
  `expire_date` date NOT NULL,
  `amount` int(11) NOT NULL,
  `sale_price` double NOT NULL,
  `user_id` int(11) NOT NULL,
  `timex` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;






CREATE TABLE `order_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `settlement_id` int(11) NOT NULL,
  `item_count` int(11) NOT NULL,
  `sum_price` bigint(20) NOT NULL,
  `admin_price` bigint(20) NOT NULL,
  `user_price` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO order_items VALUES("1","1","129","0","1","20000","2000","18000","2","2016-07-26 00:22:04");
INSERT INTO order_items VALUES("2","2","6","0","2","8000","800","7200","0","2016-07-30 01:40:44");
INSERT INTO order_items VALUES("3","3","6","0","2","8000","800","7200","0","2017-02-07 09:20:37");





CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `sum_price` bigint(20) NOT NULL,
  `items_count` int(11) NOT NULL DEFAULT '0',
  `bankmessage_id` int(11) NOT NULL DEFAULT '-1',
  `refid` varchar(20) COLLATE utf8_persian_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '-1',
  `description` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO orders VALUES("1","2","0","20000","1","-1","0","8","","2016-07-26 00:22:04");
INSERT INTO orders VALUES("2","117","0","8000","2","-1","0","8","","2016-07-30 01:40:44");
INSERT INTO orders VALUES("3","491","0","8000","2","-1","0","2","","2017-02-07 09:20:37");





CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO plugins VALUES("22","Shop","1","2016-06-15 15:36:17");





CREATE TABLE `productcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `arrangment` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO productcategories VALUES("1","4","شیشه","glass","1","1","2016-06-15 18:49:14");
INSERT INTO productcategories VALUES("2","4","قاب","frame","2","1","2016-06-15 03:13:38");
INSERT INTO productcategories VALUES("3","4","یراق الات","lace","3","1","2016-06-15 22:21:13");
INSERT INTO productcategories VALUES("4","0","محصولات","products","0","1","2016-06-17 19:50:56");





CREATE TABLE `productdiscounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `discount_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `active` smallint(1) NOT NULL,
  `approved` smallint(1) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

INSERT INTO productdiscounts VALUES("4","129","4","2019-01-10","2019-01-31","0","1","2019-01-08 21:54:47");





CREATE TABLE `productimages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) NOT NULL,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;






CREATE TABLE `productproperties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `proprety_value` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

INSERT INTO productproperties VALUES("182","129","1","4","2019-01-05 19:53:15");
INSERT INTO productproperties VALUES("183","129","3","10","2019-01-05 19:53:15");
INSERT INTO productproperties VALUES("184","129","4","11","2019-01-05 19:53:15");
INSERT INTO productproperties VALUES("185","129","5","null","2019-01-05 19:53:15");
INSERT INTO productproperties VALUES("186","129","6","null","2019-01-05 19:53:15");
INSERT INTO productproperties VALUES("187","129","7","null","2019-01-05 19:53:15");





CREATE TABLE `products` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_category_id` int(11) NOT NULL,
  `title` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `mini_detail` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `detail` text COLLATE utf8_persian_ci NOT NULL,
  `price` bigint(20) NOT NULL,
  `image` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO products VALUES("129","3","fvfvd","verrevv","<p>\n	ervqvfeververv</p>\n","0","","1","2019-01-04 19:42:16");





CREATE TABLE `products_me` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8_persian_ci DEFAULT NULL,
  `status` bit(1) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8_persian_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text COLLATE utf8_persian_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='defining the products master information';

INSERT INTO products_me VALUES("1","aaa","1","1","1","1","2018-12-31 00:33:41","1");
INSERT INTO products_me VALUES("2","aaa","1","1","1","1","2018-12-31 00:33:54","1");





CREATE TABLE `projectimages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `project_id` bigint(20) NOT NULL,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO projectimages VALUES("1","1","املاک رز","9f32af6d8e6649f1d04624048588caf9.jpg","2016-06-16 01:29:40");
INSERT INTO projectimages VALUES("2","2","","c3327e88d44f72df3335d1de0ade7ecc.jpg","2016-06-16 01:30:45");





CREATE TABLE `properties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

INSERT INTO properties VALUES("1","رنگ","2019-01-01 00:00:00");
INSERT INTO properties VALUES("3","اندازه","2019-01-01 18:27:12");
INSERT INTO properties VALUES("4","گارانتی","2019-01-01 18:27:13");
INSERT INTO properties VALUES("5","کشور تولید کننده","2019-01-01 18:27:13");
INSERT INTO properties VALUES("6","نوع","2019-01-01 18:27:13");
INSERT INTO properties VALUES("7","جنس","2019-01-01 18:27:13");





CREATE TABLE `propertydetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property_id` int(11) NOT NULL,
  `value` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO propertydetails VALUES("1","1","قرمز");
INSERT INTO propertydetails VALUES("8","3","بزرگ");
INSERT INTO propertydetails VALUES("3","1","آبی");
INSERT INTO propertydetails VALUES("4","1","سبز");
INSERT INTO propertydetails VALUES("5","1","زرد");
INSERT INTO propertydetails VALUES("6","1","مشکی");
INSERT INTO propertydetails VALUES("7","1","سفید");
INSERT INTO propertydetails VALUES("9","3","کوچک");
INSERT INTO propertydetails VALUES("10","3","متوسط");
INSERT INTO propertydetails VALUES("11","4","آواژنگ");
INSERT INTO propertydetails VALUES("12","4","کفش دوزک");
INSERT INTO propertydetails VALUES("13","4","اطلس");
INSERT INTO propertydetails VALUES("14","4","پاییزان");





CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1= active , 0= inactive',
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO roles VALUES("1","برنامه نویس سایت","1","2013-04-25 02:56:11");
INSERT INTO roles VALUES("2","کاربر عادی","1","2013-05-05 08:43:56");
INSERT INTO roles VALUES("4","مدیر کل سایت","1","2013-05-05 09:22:02");
INSERT INTO roles VALUES("5","بلاگر","0","2013-10-02 11:46:50");





CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sold` bit(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `rawprice` decimal(10,0) NOT NULL,
  `discount` decimal(10,0) NOT NULL,
  `finalprice` decimal(10,0) NOT NULL,
  `timex` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

INSERT INTO sales VALUES("1","0","0","0","0","0","0","0","2018-12-25 12:48:49","0");





CREATE TABLE `settings` (
  `site_title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `site_keywords` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `site_description` varchar(700) COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`site_title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO settings VALUES("جام نمای فردوس","جام نمای فردوس","جام نمای فردوس");





CREATE TABLE `settlements` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payable_price` bigint(20) NOT NULL,
  `pay_price` bigint(20) NOT NULL,
  `admin_price` bigint(20) NOT NULL,
  `sheba_no` varchar(30) COLLATE utf8_persian_ci NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;






CREATE TABLE `store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `timex` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;






CREATE TABLE `user_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `court_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `local_id` int(11) NOT NULL,
  `telephon` varchar(20) COLLATE utf8_persian_ci DEFAULT NULL,
  `post_code` varchar(20) COLLATE utf8_persian_ci DEFAULT NULL,
  `address` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO user_details VALUES("1","2","1","1","1","014132235265","6546654","لاهیجان - خ کاشانی - کوچه برق","2019-01-12 00:00:00");





CREATE TABLE `user_log_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `count_login` int(11) NOT NULL DEFAULT '1',
  `modified` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;






CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `sex` tinyint(4) NOT NULL DEFAULT '-1',
  `age` smallint(6) NOT NULL,
  `user_name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `mobile` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL COMMENT 'full url to image file',
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`,`user_name`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO users VALUES("1","1","مجتبي پوراصغر","1","0","","cca908a919a6e26163db7282813429d6a6ec75fe","pourasghar2006@gmail.com","","","1","2013-11-19 00:00:00","2013-08-01 09:12:38","2013-12-28 13:26:05");
INSERT INTO users VALUES("2","2","مححمد اکبری","-1","23","mohamad","111","mohamad@gmail.com","09125574645","","1","2019-01-19 00:00:00","2019-01-19 00:00:00","2019-01-12 00:00:00");



