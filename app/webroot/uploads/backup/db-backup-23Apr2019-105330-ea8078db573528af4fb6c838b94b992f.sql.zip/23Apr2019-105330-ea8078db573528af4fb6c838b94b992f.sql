

CREATE TABLE `aclitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `controller` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `action` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `action_name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `active` tinyint(2) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `controller` (`controller`,`action`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO aclitems VALUES("1","مدیریت نقش ها","roles","admin_index","لیست نقش ها","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("2","مدیریت نقش ها","roles","admin_add","افزودن نقش","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("3","مدیریت نقش ها","roles","admin_edit","ویرایش نقش","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("4","مدیریت نقش ها","roles","admin_delete","حذف نقش","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("5","مدیریت دسترسی","aclitems","admin_index","لیست دسترسی ها","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("6","مدیریت دسترسی","aclroles","admin_active_permission","فعال کردن دسترسی","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("7","مدیریت دسترسی","aclroles","admin_inactive_permission","غیرفعال کردن دسترسی","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("8","مدیریت کاربران","users","admin_index","لیست کاربران","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("9","مدیریت کاربران","users","admin_add","افزودن کاربر","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("10","مدیریت کاربران","users","admin_edit","ویرایش کاربر","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("11","مدیریت کاربران","users","admin_delete","حذف کاربر","1","0000-00-00 00:00:00");
INSERT INTO aclitems VALUES("40","مديريت بلاگ","blogs","admin_index","ليست بلاگ","1","2019-04-08 18:54:29");
INSERT INTO aclitems VALUES("41","مديريت بلاگ","blogs","admin_add","افزودن بلاگ","1","2019-04-08 18:54:29");
INSERT INTO aclitems VALUES("42","مديريت بلاگ","blogs","admin_edit","ويرايش بلاگ","1","2019-04-08 18:54:29");
INSERT INTO aclitems VALUES("43","مديريت بلاگ","blogs","admin_delete","حذف بلاگ","1","2019-04-08 18:54:29");
INSERT INTO aclitems VALUES("44","مدیریت کامنت بلاگ","blogcomments","admin_index","ليست کامنت بلاگ","1","2019-04-08 18:54:29");
INSERT INTO aclitems VALUES("45","مدیریت کامنت بلاگ","blogcomments","admin_add","افزودن کامنت بلاگ","1","2019-04-08 18:54:29");
INSERT INTO aclitems VALUES("46","مدیریت کامنت بلاگ","blogcomments","admin_edit","ویرایش نظر بلاگ","1","2019-04-08 18:54:29");
INSERT INTO aclitems VALUES("47","مدیریت کامنت بلاگ","blogcomments","admin_delete","حذف کامنت بلاگ","1","2019-04-08 18:54:29");
INSERT INTO aclitems VALUES("52","مدیریت محصول","products","admin_index","لیست محصول ها","1","2019-04-08 23:38:45");
INSERT INTO aclitems VALUES("53","مدیریت محصول","products","admin_add","افزودن محصول","1","2019-04-08 23:38:45");
INSERT INTO aclitems VALUES("54","مدیریت محصول","products","admin_edit","ویرایش محصول","1","2019-04-08 23:38:45");
INSERT INTO aclitems VALUES("55","مدیریت محصول","products","admin_delete","حذف محصول","1","2019-04-08 23:38:45");
INSERT INTO aclitems VALUES("56","مدیریت شرکت","companies","admin_index","لیست شرکت ها","1","2019-04-10 21:31:47");
INSERT INTO aclitems VALUES("57","مدیریت شرکت","companies","admin_add","افزودن شرکت","1","2019-04-10 21:31:47");
INSERT INTO aclitems VALUES("58","مدیریت شرکت","companies","admin_edit","ویرایش شرکت","1","2019-04-10 21:31:47");
INSERT INTO aclitems VALUES("59","مدیریت شرکت","companies","admin_delete","حذف شرکت","1","2019-04-10 21:31:47");
INSERT INTO aclitems VALUES("60","مدیریت صفحات","pages","admin_edit","ویرایش","1","2019-04-10 00:00:00");
INSERT INTO aclitems VALUES("61","فایل منیجر","filemanagers","admin_manager","ویرایش","1","2019-04-10 00:00:00");
INSERT INTO aclitems VALUES("66","مدیریت لینک","links","admin_index","لیست لینک ها","1","2019-04-13 17:00:30");
INSERT INTO aclitems VALUES("67","مدیریت لینک","links","admin_add","افزودن لینک","1","2019-04-13 17:00:30");
INSERT INTO aclitems VALUES("68","مدیریت لینک","links","admin_edit","ویرایش لینک","1","2019-04-13 17:00:30");
INSERT INTO aclitems VALUES("69","مدیریت لینک","links","admin_delete","حذف لینک","1","2019-04-13 17:00:30");
INSERT INTO aclitems VALUES("74","مدیریت قیمت","prices","admin_index","لیست قیمت ها","1","2019-04-13 18:16:55");
INSERT INTO aclitems VALUES("75","مدیریت قیمت","prices","admin_add","افزودن قیمت","1","2019-04-13 18:16:55");
INSERT INTO aclitems VALUES("76","مدیریت قیمت","prices","admin_edit","ویرایش قیمت","1","2019-04-13 18:16:55");
INSERT INTO aclitems VALUES("77","مدیریت قیمت","prices","admin_delete","حذف قیمت","1","2019-04-13 18:16:55");
INSERT INTO aclitems VALUES("82","مدیریت اسلایدر","sliders","admin_index","لیست اسلایدر ها","1","2019-04-16 16:07:43");
INSERT INTO aclitems VALUES("83","مدیریت اسلایدر","sliders","admin_add","افزودن اسلایدر","1","2019-04-16 16:07:43");
INSERT INTO aclitems VALUES("84","مدیریت اسلایدر","sliders","admin_edit","ویرایش اسلایدر","1","2019-04-16 16:07:43");
INSERT INTO aclitems VALUES("85","مدیریت اسلایدر","sliders","admin_delete","حذف اسلایدر","1","2019-04-16 16:07:43");





CREATE TABLE `aclroles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `aclitem_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`,`aclitem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;






CREATE TABLE `blogcomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;






CREATE TABLE `blogrelatetags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_tag_id` int(11) NOT NULL,
  `blog_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO blogrelatetags VALUES("1","1","2","2019-04-16 18:59:12");
INSERT INTO blogrelatetags VALUES("2","2","3","2019-04-16 19:00:30");
INSERT INTO blogrelatetags VALUES("3","2","4","2019-04-16 19:01:49");
INSERT INTO blogrelatetags VALUES("4","3","4","2019-04-16 19:01:49");





CREATE TABLE `blogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `little_detail` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `detail` text COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `video` varchar(300) COLLATE utf8_persian_ci DEFAULT NULL,
  `profile_id` int(11) NOT NULL COMMENT 'source profile id',
  `link` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `num_viewed` int(11) NOT NULL DEFAULT '0',
  `num_new_comment` int(11) NOT NULL DEFAULT '0',
  `num_comment` int(11) NOT NULL DEFAULT '0',
  `pinsts` smallint(6) NOT NULL DEFAULT '0',
  `pingsts` smallint(6) NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO blogs VALUES("2","1","جزییات برگزاری امتحانات دانش&zwnj;آموزان در خوزستان","همشهری آنلاین: مدیرکل آموزش و پرورش خوزستان گفت: مدارس استان شنبه، ۳۱ فروردین&zwnj;ماه بازگشایی می&zwnj;شوند و روند ادامه تحصیل دانش&zwnj;آموزان تا پایان اردیبهشت&zwnj;ماه ادامه پیدا می&zwnj;کند.","&lt;p&gt;\\n	به گزارش ایسنا، محمد تقی&amp;zwnj;زاده اظهار کرد: تمامی مدارس شهرهای سیل&amp;zwnj;زده استان خوزستان که تا پایان هفته جاری تعطیل اعلام شده بودند، از روز شنبه ۳۱ فروردین&amp;zwnj;ماه بازگشایی می&amp;zwnj;شوند و روند ادامه تحصیل دانش&amp;zwnj;آموزان تا پایان اردیبهشت&amp;zwnj;ماه ادامه پیدا می&amp;zwnj;کند.&lt;br /&gt;\\n	&lt;br /&gt;\\n	وی با اشاره به اهمیت پایه تحصیلی دوازدهم، عنوان کرد: در سال&amp;zwnj;های گذشته دانش&amp;zwnj;آموزان پایه دوازدهم در شهریورماه می&amp;zwnj;توانستند امتحان مجدد دهند اما امسال در کل استان خوزستان دانش&amp;zwnj;آموزان در مقطع دوازدهم علاوه بر خردادماه می&amp;zwnj;توانند در تیرماه، مردادماه و شهریورماه، مجدد امتحان دهند و نمره کسب شده، نمره قبولی خرداد برای آن&amp;zwnj;ها محسوب می&amp;zwnj;شود.&lt;br /&gt;\\n	&lt;br /&gt;\\n	مدیرکل آموزش و پرورش خوزستان افزود: امتحانات پایه نهم در سال&amp;zwnj;های گذشته به&amp;zwnj;صورت هماهنگ استانی برگزار می&amp;zwnj;شد که این موضوع از دستور کار استان خوزستان خارج شد و امتحانات پایه نهم تا حدی که تدریس شد، به شکل منطقه&amp;zwnj;ای برگزار خواهد شد.&lt;br /&gt;\\n	&lt;br /&gt;\\n	تقی&amp;zwnj;زاده با اشاره به روند برگزاری امتحانات دیگر پایه&amp;zwnj;ها، اظهار کرد: در دوره متوسطه اول امتحانات تا حدودی که تدریس شد، برگزار می&amp;zwnj;شود و درصورتی&amp;zwnj;که حجمی از کتاب&amp;zwnj;ها باقی ماند، سال تحصیلی آینده یک هفته زودتر به&amp;zwnj;منظور جبران عقب&amp;zwnj;ماندگی&amp;zwnj;ها آغاز خواهد شد.&lt;br /&gt;\\n	&lt;br /&gt;\\n	وی گفت: در دوره ابتدایی عملاً کتاب&amp;zwnj;ها به اتمام رسیده بود و در سال جدید کتاب&amp;zwnj;های درسی مرور می&amp;zwnj;شود، به همین دلیل مشکل جدی در بحث مقاطع ابتدایی وجود ندارد.&lt;br /&gt;\\n	&lt;br /&gt;\\n	مدیرکل آموزش&amp;zwnj;وپرورش خوزستان با اشاره به مشکل تردد دانش&amp;zwnj;آموزان در مناطق سیل&amp;zwnj;زده، عنوان کرد: ۵۰۰ میلیون تومان اعتبار به&amp;zwnj;منظور ایاب و ذهاب دانش&amp;zwnj;آموزان مناطق سیل&amp;zwnj;زده برای استان خوزستان در نظر گرفته شد و هر منطقه موظف است برای دانش&amp;zwnj;آموزان حتی اگر یک نفر باشد، سرویس ایاب و ذهاب رایگان فراهم کند.&lt;br /&gt;\\n	&lt;br /&gt;\\n	وی افزود: دانش&amp;zwnj;آموزانی که در روستاهای زیر آب رفته ساکن هستند و امکان بازگشت مجدد برای آن&amp;zwnj;ها وجود ندارد، در همان مناطقی که ساکن هستند به مدرسه می&amp;zwnj;روند.&lt;/p&gt;","0b601dba1d0594dce4a02f852e804ec1.jpg","","0","http://www.hamshahrionline.ir/news/437435/%D8%AC%D8%B2%DB%8C%DB%8C%D8%A7%D8%AA-%D8%A8%D8%B1%DA%AF%D8","0","0","0","0","0","1","2019-04-16 18:59:11");
INSERT INTO blogs VALUES("3","1","حناچی: دولت برای رابطه شهرداری و شورای شهر چارچوب تعیین کند","همشهری&zwnj;آنلاین: شهردار تهران با اشاره به این&zwnj;که رابطه شهرداری با شورای شهر تعریف شده نیست؛ گفت: در رابطه شهرداری و شورا آیین&zwnj;نامه و چارچوبی نیست و بد نیست پیشنهاد بدهیم دولت برای این رابطه چارچوبی تعیین کند.","&lt;p&gt;\\n	به گزارش ایسنا، &lt;a href=&quot;http://www.hamshahrionline.ir/news/423961/%D8%B2%D9%86%D8%AF%DA%AF%DB%8C%D9%86%D8%A7%D9%85%D9%87-%D9%BE%DB%8C%D8%B1%D9%88%D8%B2-%D8%AD%D9%86%D8%A7%DA%86%DB%8C-%DB%B1%DB%B3%DB%B4%DB%B2&quot;&gt;پیروز حناچی&lt;/a&gt; در جلسه شورای معاونان شهرداری تهران که&amp;nbsp;در معاونت فنی و عمرانی شهرداری برگزار شد، بر پاسخگویی دقیق مدیران شهری به سوالات اعضای شورای شهر تاکید کرد و گفت: تلاش کنید به صورت درست و مستدل به سوالات اعضای شورا پاسخ دهید. برخی اعضای شورای شهر گلایه دارند که وقتی نسبت به پاسخ ها اعتراض دارند اعتراضشان باز هم به همان مقام ارجاع می شود.&lt;/p&gt;\\n&lt;p&gt;\\n	او عنوان کرد: واقعیت این است که رابطه ما با شورا مثل مجلس تعریف شده نیست؛ در مجلس آیین&amp;zwnj;نامه و چارچوب مشخصی درباره سوال نمایندگان از وزرا وجود دارد، اما در رابطه شهرداری و شورای شهر چنین چارچوبی نیست و اتفاقا بد نیست پیشنهاد بدهیم دولت برای این رابطه چارچوبی تعیین کند.&lt;/p&gt;\\n&lt;p&gt;\\n	شهردار تهران در ادامه در تشریح سفر اخیر خود به خوزستان گفت: متاسفانه سیل اخیر زمین&amp;zwnj;های کشاورزان را از بین برده و این در حالی است که کشاورزان خوزستانی در انتظار سال خوبی برای برداشت محصولات&amp;zwnj;شان بودند. به همین دلیل در برخی نقاط که نیروهای عملیاتی می خواستند مسیر های آب را هدایت کنند و مثلا دژی را بشکنند با مقاومت مردمی مواجه می شدند، چراکه بیم ورود آب به زمین های کشاورزی را داشتند.&lt;br /&gt;\\n	او از برخی فعالیت&amp;zwnj;های هماهنگ میان مردم و مسئولان در تعدادی از شهرها تقدیر کرد و یادآور شد: در سوسنگرد مردم به کمک مسئولان دژی را ساختند که به خوبی جلوی ورود آب به برخی بخش ها را گرفت.&lt;/p&gt;\\n&lt;p&gt;\\n	شهردار تهران یکی از مشکلات پیش روی بعضی از شهرهای خوزستان را مسائل بهداشتی دانست و گفت: در برخی شهرها با بالا آمدن سطح آب، فاضلاب به خانه ها وارد شده و اگر از هم اکنون تدبیر نشود در این مناطق با بروز بیماری های عفونی مواجه خواهیم شد. بر همین مبنا معتقدم ما در روزهای آینده همچنان با تبعات این سیل در خوزستان دست به گریبان خواهیم بود.&lt;/p&gt;\\n&lt;p&gt;\\n	او با مثبت و موثر دانستن عملکرد شهرداری تهران در خوزستان تاکید کرد: حضور آقای رستمی، معاون امور مناطق در این عملیات به دلیل تجربه بالای ایشان در حل مشکلات منطقه و ایجاد هماهنگی های لازم، بسیار موثر بوده است. مردم هم در مناطقی که شهرداری تهران فعال است از اقدامات انجام شده رضایت داشتند، البته در بخش توزیع اقلام مصرفی شکایت هایی وجود داشت که به نظر من طبیعی است. در واقع، در شرایط فعلی هر اقدامی آن جا انجام شود قطعا عده ای معترض خواهند بود. ضمن این که درخواست های مردم در مناطق مختلف خوزستان متفاوت بود؛ به طور مثال، در برخی روستاها و مناطق عشایری مردم خواستار علوفه برای دام هایشان بودند.&lt;/p&gt;\\n&lt;p&gt;\\n	به گفته حناچی در روزهای آینده نیروهای شهرداری از آق قلا و سایر مناطق سیل زده کشور خارج شده و در خوزستان متمرکز خواهند شد و در هماهنگی با سایر دستگاه ها به امدادرسانی به سیل زدگان خواهند پرداخت.&lt;/p&gt;\\n&lt;p&gt;\\n	او تصریح کرد: هم اکنون در دولت این نگرانی وجود دارد که با گرم شدن هوا روان&amp;zwnj;آب&amp;zwnj;های ناشی از ذوب شدن برف&amp;zwnj;ها باعث شود که باز هم میزان آب ورودی به سدها افزایش یابد و مسئولان مجبور شوند که دریچه سدها را باز کنند.&lt;/p&gt;\\n&lt;p&gt;\\n	حناچی همچنین از تصویب لایحه دوفوریتی برای کمک به مناطق سیل&amp;zwnj;زده در شورای شهر قدردانی و ابراز رضایت کرد و در ادامه به موضوع پهنه&amp;zwnj;بندی سیل در تهران اشاره کرد و گفت: تمامی دستگاه&amp;zwnj;های ذیربط در شهرداری این موضوع را هر چه سریع تر انجام دهند. در بحران هایی مانند سیل اطلاع رسانی پیامکی حداقل کاری است که می توانیم انجام دهیم که بسیاری از مشکلات را حل می کند. اقدامات بعدی هم توسط دستگاه ها باید انجام شود و برنامه های لازم برای آن تدارک دیده شود. &amp;nbsp;&lt;/p&gt;\\n&lt;p&gt;\\n	شهردار تهران با تاکید بر ضرورت انتقال تجربیات مقابله با سیل در تهران به سایر شهرها تصریح کرد: از شهرداران مناطق می خواهم به صورت فنی و علمی لکه گیری معابر آسیب دیده از بارندگی های اخیر را انجام دهند. بارندگی، آسفالت برخی معابر را شسته و به آن آسیب زده که لازم است همه دستگاه های ذیربط هر چه زودتر نسبت به لکه گیری فنی و درست این معابر اقدام کنند. کسب رضایت مردم در این زمینه برای ما مهم است و مردم باید بدانند که مدیریت شهری به فکر رفاه حال آنان است و اگر نوروزگاه برای شادی مردم برپا می کند، در عین حال به فکر حل مشکلات آنها هم هست.&lt;/p&gt;\\n&lt;p&gt;\\n	شهردار تهران عنوان کرد: در انتهای سال گذشته و ابتدای سال جدید کار بزرگی انجام شد که متاسفانه به خاطر اخبار مربوط به سیل توجه کافی به آن نشد و آن افتتاح&lt;a href=&quot;http://www.hamshahrionline.ir/news/434243/%D8%A2%D8%B4%D9%86%D8%A7%DB%8C%DB%8C-%D8%A8%D8%A7-%D8%AE%D8%B7-%DB%B6-%D9%85%D8%AA%D8%B1%D9%88&quot;&gt; خط ۶&lt;/a&gt; و ۷ مترو بود. رئیس&amp;zwnj;جمهور نیز در مراسم افتتاح خط ۶ حاضر بود و قول همکاری و پیگیری داد که این بزرگ&amp;zwnj;ترین موفقیت ما بود. افتتاح ۱۲۵۰ هکتار فضای سبز نوار شمالی تهران هم اقدام قابل توجهی محسوب می شود.&lt;/p&gt;\\n&lt;p&gt;\\n	شهردار تهران با تشکر از تمامی کارکنان شهرداری که در کنترل بحران احتمالی و جلوگیری از سیل در تهران نقش داشتند، اظهار کرد: در نوروز امسال رئیس&amp;zwnj;جمهور نگران وضعیت تهران بود که خوشبختانه با درایت و برنامه&amp;zwnj;ریزی درست مشکلی پیش نیامد و من خوشحالم که آرامش را به شهر و شهروندان بازگرداندیم.&lt;/p&gt;\\n&lt;p&gt;\\n	&amp;nbsp;حناچی در خاتمه تصریح کرد: به دلیل پیش&amp;zwnj;بینی درست و اقدامات بهنگام، در آن شرایط دشوار کسی نگران تهران نبود هر چند وزیر کشور دغدغه هایی داشتند مبنی بر این&amp;zwnj;که در روز ۱۲ فروردین اتفاقی در تهران نیفتد. ما باید تجربه و برنامه&amp;zwnj;ریزی های خودمان را به سایر شهرها منتقل کنیم تا هم تلاش&amp;zwnj;های همکارانم دیده شود و هم آن&amp;zwnj;ها بدانند که با برنامه&amp;zwnj;ریزی می&amp;zwnj;توان جلوی بحران را گرفت.&lt;/p&gt;","57f4a5fff154f13c6686dcdf2ac50d58.jpg","","0","","27","0","0","0","0","1","2019-04-16 19:00:30");
INSERT INTO blogs VALUES("4","1","مصوبه کمیسیون امنیت مجلس برای اقدام متقابل برابر اعلام سپاه به عنوان سازمان تروریستی","همشهری آنلاین: متن کامل مصوبه کمیسیون امنیت ملی و سیاست خارجی مجلس برای طرح اقدام متقابل برابر اعلام سپاه به عنوان سازمان تروریستی توسط آمریکا منتشر شد.","&lt;p&gt;\\n	فارس نوشت:&amp;nbsp;متن کامل مصوبه کمیسیون امنیت ملی و سیاست خارجی &lt;a href=&quot;http://www.hamshahrionline.ir/news/67986/%D8%A2%D8%B4%D9%86%D8%A7%DB%8C%DB%8C-%D8%A8%D8%A7-%D9%85%D8%AC%D9%84%D8%B3-%D8%B4%D9%88%D8%B1%D8%A7%DB%8C-%D8%A7%D8%B3%D9%84%D8%A7%D9%85%DB%8C&quot;&gt;مجلس شورای اسلامی&lt;/a&gt; برای طرح اقدام متقابل در برابر اعلام &lt;a href=&quot;http://www.hamshahrionline.ir/news/75211/%D8%A2%D8%B4%D9%86%D8%A7%DB%8C%DB%8C-%D8%A8%D8%A7-%D8%B3%D9%BE%D8%A7%D9%87-%D9%BE%D8%A7%D8%B3%D8%AF%D8%A7%D8%B1%D8%A7%D9%86-%D8%A7%D9%86%D9%82%D9%84%D8%A7%D8%A8-%D8%A7%D8%B3%D9%84%D8%A7%D9%85%DB%8C&quot;&gt;سپاه &lt;/a&gt;به عنوان سازمان تروریستی توسط آمریکا منتشر شد.&lt;/p&gt;\\n&lt;p&gt;\\n	متن مصوبه کمیسیون امنیت ملی مجلس به شرح ذیل است:&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۱)&lt;/p&gt;\\n&lt;p&gt;\\n	به منظور اقدام متقابل در برابر تصمیم و یا اقدام ایالات متحده آمریکا در تضعیف صلح و ثبات منطقه&amp;zwnj;ای و بین&amp;zwnj;المللی و از آنجا که این رژیم برخلاف اصول مسلم حقوق بین&amp;zwnj;الملل، سپاه پاسداران انقلاب اسلامی را که مطابق اصل یکصد و پنجاهم قانون اساسی به عنوان یکی از ارکان حاکمیتی دفاعی ایران شناخته می&amp;zwnj;شود سازمان تروریستی خارجی اعلام نموده است. به موجب این قانون نیروهای فرماندهی مرکزی آمریکا (سنت&amp;zwnj;کام) و سازمان&amp;zwnj;ها و یا نهادهای تحت اختیار این فرماندهی، تروریست اعلام می&amp;zwnj;شوند و هرگونه کمک اعم از نظامی اطلاعاتی، مالی، فنی، آموزشی، خدماتی و تدارکاتی به این نیروها همکاری در اقدام تروریستی محسوب می&amp;zwnj;گردد.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۲)&lt;/p&gt;\\n&lt;p&gt;\\n	دولت جمهوری اسلامی ایران مؤظف است در چارچوب مصوبات شورای عالی امنیت ملی در برابر اقدامات تروریستی نیروهای آمریکایی که منافع جمهوری اسلامی ایران را به مخاطره می&amp;zwnj;اندازند، اقدامات متقابل و قاطع براساس این قانون به عمل آورد.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۳)&lt;/p&gt;\\n&lt;p&gt;\\n	دولت جمهوری اسلامی ایران و نیروهای مسلح مؤظفند در زمان مقتضی با اقدامات پیشگیرانه و دفاع پیش&amp;zwnj;دستانه به گونه&amp;zwnj;ای عمل کنند که نیروهای آمریکایی نتوانند از هرگونه و امانات علیه منافع جمهوری اسلامی ایران استفاده کنند.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۴)&lt;/p&gt;\\n&lt;p&gt;\\n	ستاد کل نیروهای مسلح مکلف است با همکاری وزارت اطلاعات و بهره&amp;zwnj;گیری از امکانات و توانایی سازمان اطلاعات سپاه پاسداران انقلاب اسلامی و سایر واحدهای اطلاعاتی نیروهای مسلح جمهوری اسلامی ایران فهرست و اسامی فرماندهان ستاد فرماندهی مرکزی آمریکا (سنت&amp;zwnj;کام) و سازمان&amp;zwnj;ها و نهادهایی که تحت اختیار این فرماندهی می&amp;zwnj;باشند و از تروریست&amp;zwnj;ها حمایت و پشتیبانی می&amp;zwnj;نمایند را برای تعقیب قضایی اعلام نموده و قوه قضاییه جمهوری اسلامی ایران حداکثر ظرف مدت&amp;zwnj; سه ماه از تصویب این قانون سازوکاری را ایجاد نماید که براساس آن اسامی اعلام شده را به عنوان یک سازما و افراد تروریستی تحت تعقیب و مجازات قضایی براساس قانون مجازات اسلامی قرار دهد.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۵)&lt;/p&gt;\\n&lt;p&gt;\\n	دولت مؤظف است از کلیه اشخاص حقیقی و حقوقی داخلی و خارجی که با سپاه پاسداران انقلاب اسلامی همکاری می&amp;zwnj;کنند و از این جهت در معرض آسیب قرار می&amp;zwnj;گیرند حمایت حقوقی، مادی و معنوی نماید.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۶)&lt;/p&gt;\\n&lt;p&gt;\\n	ستاد کل نیروهای مسلح و وزارتخانه&amp;zwnj;های امور خارجه و دفاع و پشتیبانی نیروهای مسلح مؤظفند با استفاده از ظرفیت&amp;zwnj;های حقوقی، سیاسی و دیپلماسی دفاعی خود برای تعطیلی پایگاه&amp;zwnj;های آمریکایی در منطقه تلاش نموده و بهره&amp;zwnj;مندی نیروهای آمریکایی از تأسیسات، &amp;zwnj;تجهیزات، منابع مالی و سایر کمک&amp;zwnj;های احتمالی کشورهای منطقه را خاتمه دهند.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۷)&lt;/p&gt;\\n&lt;p&gt;\\n	کلیه کشورها و اشخاص حقیقی و حقوقی که به هر نحوی از تصمیم ایالات متحده آمریکا مبنی بر تروریست اعلام کردن سپاه پاسداران انقلاب اسلامی تبعیت یا حمایت نمایند در هنگام اجرای آن تصمیم کمک کنند مشمول عمل متقابل جمهوری اسلامی ایران قرار می&amp;zwnj;گیرند و هر گونه محرومیت و محدودیت علیه سپاه پاسداران انقلاب اسلامی و کارکنان و تأسیسات و تجهیزات سپاه پاسداران انقلاب اسلامی در هر نقطه دنیا اقدام علیه جمهوری اسلامی ایران محسوب و مشمول عمل متقابل می&amp;zwnj;گردد.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۸)&lt;/p&gt;\\n&lt;p&gt;\\n	کلیه دستگاه&amp;zwnj;های اجرایی موضوع ماده پنج قانون مدیریت خدمات کشوری مصوب ۱۳۸۶.۷.۱۸ مجلس شورای اسلامی همچنین کلیه مؤسسات و شرکـت&amp;zwnj;های دولتی، عمومی، غیر دولتی، مؤسسات مالی، بانک&amp;zwnj;ها، &amp;zwnj;بیمه&amp;zwnj;ها و شرکت&amp;zwnj;های خصوصی مکلف به همکاری و ارائه خدمات به سپاه پاسداران انقلاب اسلامی و اشخاص حقیقی و حقوقی شاغل، وابسته یا مرتبط بوده و چنانچه به استناد تحریم&amp;zwnj;های خارجی یا بین&amp;zwnj;المللی از همکاری و ارائه خدمات خودداری نمایند مجرم و مستوجب مجازات تعزیری درجه ۵ قانون مجازات اسلامی می&amp;zwnj;گردند.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۹)&lt;/p&gt;\\n&lt;p&gt;\\n	دولت جمهوری اسلامی ایران مؤظف است ضمن اعتراض و اقدام حقوقی به تصمیم غیرقانونی ایالات متحده آمریکا در تروریست نامیدن سپاه پاسداران انقلاب اسلامی در مراجع بین&amp;zwnj;المللی، از طریق مراودات دو جانبه و چند جانبه یا کشورها و رایزنی با مجامع و سازمان&amp;zwnj;های بین&amp;zwnj;المللی از حداکثر توان خود برای بی&amp;zwnj;اثر کردن اقدام آمریکا در نقض مصونیت حاکمیتی ارکان دفاعی جمهوری اسلامی ایران استفاده کند.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۱۰)&lt;/p&gt;\\n&lt;p&gt;\\n	سازمان برنامه و بودجه کشور مکلف است منابع مورد نیاز برای اجرای این قانون را سالیانه در بودجه سنواتی دستگاه&amp;zwnj;های مجری این قانون پیش&amp;zwnj;بینی و تخصیص صددرصد را صادر نماید.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۱۱)&lt;/p&gt;\\n&lt;p&gt;\\n	دولت و کلیه دستگاه&amp;zwnj;های مشمول این قانون مؤظف هستند هر چهار ماه یکبار گزارش عملکرد خود را به کمیسیون امنیت ملی و سیاست خارجی برای طرح در مجلس شورای اسلامی ارائه نمایند.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۱۲)&lt;/p&gt;\\n&lt;p&gt;\\n	کلیه تکالیف مرتبط با نیروهای مسلح مقرر در این قانون براساس تدابیر فرماندهی کل قوا قابل اجرا می&amp;zwnj;باشد.&lt;/p&gt;\\n&lt;p&gt;\\n	ماده (۱۳)&lt;/p&gt;\\n&lt;p&gt;\\n	این قانون از زمان تصویب لازم&amp;zwnj;الاجرا است.&lt;/p&gt;","2b959e512f2ce2afaa219cf34b1f8f0c.jpg","","0","http://www.hamshahrionline.ir/news/437398/%D9%85%D8%B5%D9%88%D8%A8%D9%87-%DA%A9%D9%85%DB%8C%D8%B3%DB","2","0","0","0","0","1","2019-04-16 19:01:49");





CREATE TABLE `blogtags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO blogtags VALUES("1","خوزستان","2019-04-16 18:59:11");
INSERT INTO blogtags VALUES("2","حنانی","2019-04-16 19:00:30");
INSERT INTO blogtags VALUES("3","مجلس","2019-04-16 19:01:49");





CREATE TABLE `companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `arrangment` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO companies VALUES("1","شرکت گلرنگ","256152e314e4fbbf0d44d9332e27f213.jpg","1","1","2019-04-10 23:41:27");
INSERT INTO companies VALUES("2","افق کوروش","a31bd0841d3b7101626fce61f90a0f26.png","2","1","2019-04-10 23:43:43");





CREATE TABLE `links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `link` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `detail` varchar(300) COLLATE utf8_persian_ci DEFAULT NULL,
  `link_type` tinyint(4) NOT NULL,
  `arrangment` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO links VALUES("1","دکتر اینجاست","https://drinjast.com/","شبکه اجتماعی سلامت، جستجوی پزشکان، جستجوی بیمارستان ها و کلینیک های پزشکی","0","1","1","2019-04-13 17:21:54");
INSERT INTO links VALUES("2","سیتی تومب","http://www.citytomb.com/","با استفاده از سیتی تومب، می توانید برای عزیزان از دست رفته‌ی خود ، صفحه آرامگاهی در فضای مجازی داشته باشید تا یاد و خاطره آنها همیشه زنده باشد.","1","2","1","2019-04-13 17:24:35");





CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `body` text COLLATE utf8_persian_ci NOT NULL,
  `meta` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `keyword` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `arrangment` tinyint(2) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO pages VALUES("1","درباره ما","&lt;p style=&quot;text-align: right;&quot;&gt;\\n	جام نمای فردوس از اولبین شرکت های صنایع شیشه در تهران می باشد که کار خود را از سال 1320 آغاز کرده است..&lt;/p&gt;\\n&lt;p style=&quot;text-align: right;&quot;&gt;\\n	این شرکت دارای بخش های زیر می باشد&lt;/p&gt;\\n","پیشرو فناور","جام نما#فردوس","0","1","0000-00-00 00:00:00");
INSERT INTO pages VALUES("2","تماس با ما","&lt;p&gt;\\n	جام نمای فردوس از اولبین شرکت های صنایع شیشه در تهران می باشد که کار خود را از سال 1320 آغاز کرده است..&lt;br /&gt;\\n	&lt;br /&gt;\\n	این شرکت دارای بخش های زیر می باشد&lt;/p&gt;\\n","","","0","0","0000-00-00 00:00:00");





CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO plugins VALUES("3","Blog","1","2019-04-08 18:54:30");
INSERT INTO plugins VALUES("5","Product","1","2019-04-08 23:38:45");
INSERT INTO plugins VALUES("6","Company","1","2019-04-10 21:31:47");
INSERT INTO plugins VALUES("8","Link","1","2019-04-13 17:00:30");
INSERT INTO plugins VALUES("10","Price","1","2019-04-13 18:16:55");
INSERT INTO plugins VALUES("12","Slider","1","2019-04-16 16:07:43");





CREATE TABLE `prices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `price` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `arrangment` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO prices VALUES("1","قیمت دلار","1450000","1","1","2019-04-13 18:38:15");





CREATE TABLE `productcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `arrangment` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO productcategories VALUES("2","1","چدن","chodan","4274968bb1843b997e36f2b4e5e0f013.jpg","2","1","2019-04-09 17:44:25");
INSERT INTO productcategories VALUES("4","0"," انواع ورق ","varagh","019d0618f6a9b8758d0770e605771e0d.jpg","2","1","2019-04-16 18:06:01");
INSERT INTO productcategories VALUES("5","4","انواع ورق گرم و سرد ","varagh garm sard","","1","1","2019-04-16 18:06:41");
INSERT INTO productcategories VALUES("6","0","تیرآهن و هاش ","tirche","bae4d3a9cb18bdb4256c5fd0f504789f.jpg","1","1","2019-04-16 18:14:09");
INSERT INTO productcategories VALUES("7","6","انواع تیرآهن","anvatirahan","","1","1","2019-04-16 18:14:35");
INSERT INTO productcategories VALUES("8","6","انواع ریل","reil","","2","1","2019-04-16 18:18:58");
INSERT INTO productcategories VALUES("9","5","انواع ورق گرم ","varaghgarm","","1","1","2019-04-16 18:19:32");
INSERT INTO productcategories VALUES("10","5","انواع ورق سرد و پوشش دار ","psheshdar","","2","1","2019-04-16 18:20:07");
INSERT INTO productcategories VALUES("11","9","ورق سیاه","varaghsiah","","1","1","2019-04-16 18:20:35");





CREATE TABLE `productimages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) NOT NULL,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO productimages VALUES("1","1","","83200144aa8419ed564be8176642bbc6.jpg","2019-04-20 19:39:09");
INSERT INTO productimages VALUES("2","1","","49ea1b8baf37e28e91dd5d9fcdd2cde5.jpg","2019-04-20 19:39:09");
INSERT INTO productimages VALUES("3","2","","800c5915e249196bb34a457b0fcfc670.jpg","2019-04-20 19:39:09");
INSERT INTO productimages VALUES("4","2","","43d2bb85a0a840973d3c3d13bc73bbe8.jpg","2019-04-20 19:39:09");
INSERT INTO productimages VALUES("5","3","تصویر اصلی","5a926e01948b309530fae726e892c4ee.jpg","2019-04-20 19:57:05");
INSERT INTO productimages VALUES("6","3","تصویر میانی","328f204324a320da7b87b02558b3998f.jpg","2019-04-20 19:57:05");
INSERT INTO productimages VALUES("7","4","سیسی","1fb5057d134ad4ff5b01c0a7a582bd3f.jpg","2019-04-20 19:59:46");
INSERT INTO productimages VALUES("8","4","سیسی","4af08700f4d6ff15e6661060faf61326.jpg","2019-04-20 19:59:46");
INSERT INTO productimages VALUES("9","5","","83efd82ff827cdb555f1c59c6df88492.jpg","2019-04-20 22:28:13");
INSERT INTO productimages VALUES("10","6","","527e64bfe0956d1944bb09991bc12f8f.jpg","2019-04-20 22:29:05");





CREATE TABLE `products` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_category_id` int(11) NOT NULL,
  `title` varchar(300) COLLATE utf8_persian_ci NOT NULL,
  `mini_detail` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `detail` text COLLATE utf8_persian_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_category_id` (`product_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO products VALUES("1","10","Internet Download Manager (IDM) 6.32 Build 11 Retail + Portable مدیریت دانلود","Internet Download Manager یا همان IDM یک نرم‌ افزار مدیریت دانلود است که تنها برای سیستم‌ عامل مایکروسافت ویندوز قابل استفاده‌ است. Internet Download Manager ، دانلودها را به چند قطعه تقسیم می‌کند تا عملیات دانلود سریع‌ تر انجام شود. IDM با برنامه‌های اینترنت اکسپلورر، اپرا، موزیلا فایرفاکس، گوگل کروم کار می‌کند. تاکنون گزارشی مبنی بر اینکه Internet Download Manager محتوی جاسوس‌افزار یا adware باشد، منتشر نشده‌است. IDM می‌تواند فیلم‌هایی که در وبسایت‌ ها مشاهده می‌کنید را دانلود کند. ","<p>\n	هنگامی که فیلمی از اینترنت پخش می&zwnj;شود، به طور خودکار عبارتی را به نام Download this video در کنار صفحهٔ فیلم یا صدا ظاهر می&zwnj;شود که با کلیک بر آن می&zwnj;توان فیلم یا صدا را بارگیری کرد. با برنامه Internet Download Manager ميتوانيد سرعت دانلود را افزايش دهد. بر خلاف ديگر دانلود منيجر ها که قبل از شروع به دانلود فايل ها را قطعه قطعه مي کنند IDM در هنگام دانلود و بسته به سرعت اينترنت يا ... File ها را قطعه قطعه کرده و دانلود مي کند که اين عمل باعث بهبود سرعت دانلود و دريافت File خواهد شد از ويژگي های نرم افزار Internet Download Manager مي توان به ظاهری ساده، پشتيباني از اکثر مرور گرهای محبوب، نصب آسان، قابليت ادامه يافتن دانلود بعد از قطع اتصال از اينترنت، زمانبندی دانلود ها و ... اشاره کرد.</p>\n<h2>\n	قابلیت های نرم افزار Internet Download Manager :</h2>\n<ul>\n	<li>\n		سازگاری با انواع مرورگرهای محبوب برای اجرا نمودن خودکار برنامه به منظور مدیریت دانلود فایلها</li>\n	<li>\n		قابلیت ادامه دانلود های نیمه تمام از جایی که ارتباط اینترنتی شما بنا به دلایلی قطع شده است</li>\n	<li>\n		دانلود فایل های ویدیویی FLV از سایت های YouTube</li>\n	<li>\n		پشتیبانی از انواع پروکسی سرورها مانند Microsoft ISA, FTP proxy servers</li>\n	<li>\n		ویژگی Speed Limiter برای محدود کردن سرعت دانلود یک فایل مشخص</li>\n	<li>\n		توانایی دسته بندی فایل ها با توجه به سلیقه شخصی</li>\n	<li>\n		قابلیت کشیدن و رها کردن Drag &amp; Drop لینک ها</li>\n	<li>\n		پشتیبانی از فایل های ZIP و اجرای آنها بعد از دانلود</li>\n	<li>\n		پشتیبانی از پروتکل های HTTP, FTP, MMS و HTTPS</li>\n	<li>\n		جلوگیری از دانلود فایل های تکراری که قبلا دانلود شده اند</li>\n	<li>\n		پشتیبانی از زبان <b class=\"text-danger\">پارسی</b></li>\n</ul>\n","1","2019-04-20 19:39:08");
INSERT INTO products VALUES("3","4","PotPlayer 1.7.18346 + Portable پخش حرفه ای مالتی مدیا","PotPlayer یکی از پلیرهای رایگان، حرفه ای و پرطرفدار با پشتیبانی از زبان پارسی نزد کاربران اینترنتی میباشد که طیف وسیعی از فرمتهای صوتی و تصویری را پشتیبانی میکند و شامل پوسته هایی با موضوعات مختلف میباشد که کاربران حتی با نوع سیستم عامل خود میتوانند هماهنگ کنند.","<p>\n	به گفته کاربران اینترنتی ، PotPlayer حتی از KMPlayer بهتر عمل میکند و به خوبی از انواع زیر نویس ها پشتیبانی میکند و کدک های موجود در این نرم افزار شما را از نصب کدک های اضافی جهت پخش بهتر ویدئوها بی نیاز میکند.<br />\n	امکان تنظیم نور ، صدا ، سرعت پخش ویدئوها ، فونت و رنگ زیرنویس ، کلیدهای میانبر و ... امکاناتی است که نرم افزار برای رضایتمندی بیشتر در اختیار کاربران خود قرار داده است.</p>\n","1","2019-04-20 19:57:05");
INSERT INTO products VALUES("4","9","SideFX Houdini FX 17.5.229 طراحی و مدلسازی 3 بعدی","SideFX Houdini FX نرم افزاری قدرتمند برای مدل سازی و خلق افکت های ویژه و درعین حال یک پکیج کاربردی برای طرح های سه بعدی می باشد. این نرم افزار این امکان را برای شما فراهم می نماید تا طرح هایی زیبا و حرفه ای را بدون نیاز به استفاده از پلاگین های اضافی یا گروهی از برنامه نویس ها ایجاد نمایید.","<p>\n	با استفاده از این برنامه با بکارگیری فناوری Houdini می توانید افکتهای ویدئویی خیره کننده و جذاب و انیمیشن های عالی را خلق نمایید، در میان ابتکاری بوجود امد ه در دهمین نسخه نرم افزار لازم به ذکر است که می توان از این برنامه بصورت متحد برروی چندین رایانه برروی یک شبکه داخلی لستفاده نمود ونیز محدودیتهای رفتاری افکتهای سیالات در این نسخه کاهش پیدا نموده و ابزار جدید Pyro FX برای ایجاد افکتهای دود و آتش افزوده شده است، علاوه بر این فناوری Interactive Photorealistic Rendering برای مشاهده سریع تغییرات بوجودآمده در صحنه های سه بعدی تزیینی استفاده شده است، ومی توانید با اطلاعات خود بصورت سه بعدی کار نمایید و می توانید با این برنامه تصاویر پیچیده و زیبا بدون نیاز به برنامه نویسی حرفه ای ایجاد نمایید ونیز با استفاده از افکتهای ویژه ویدئویی و انیمیشن نرم افزار قادر یه ساخت فیلمهای زیبا و جذاب خواهید بود. SideFX Houdini بگونه ای متفاوت ایجاد افکتهای پویا و بصری را با نمونه های زیبا ممکن می سازد.</p>\n<div class=\"card-body card-post-body\">\n	<h2>\n		قابلیتهای نرم افزار SideFX Houdini</h2>\n	<ul>\n		<li>\n			خلق افکتهای ویژه ویدئویی و انیمشن های جذاب و خیره کننده</li>\n		<li>\n			کار بصورت سریع، هوشمند و انعطاف پذیر</li>\n		<li>\n			ارائه سطح جدیدی از ادراک طرح های گرافیکی</li>\n		<li>\n			کنترل برروی تمامی ابزارها</li>\n		<li>\n			بهره گیری از واسط گرافیکی مستقیم و کاربرپسند</li>\n		<li>\n			مدل سازی چندضلعی</li>\n		<li>\n			مدل سازی NURBS</li>\n		<li>\n			خلق اشیای هندسی</li>\n		<li>\n			ابزارهای اضافی برای ویرایش حرکات</li>\n		<li>\n			انیمشن رویه ای و ویرایش حرکات</li>\n		<li>\n			خلق و ویرایش صداهای زیبا</li>\n		<li>\n			مدیریت نور و سایه ها</li>\n		<li>\n			پشتیبانی یکپارچه از زبان برنامه نویسی Python</li>\n		<li>\n			و ...</li>\n	</ul>\n</div>\n","1","2019-04-20 19:59:46");
INSERT INTO products VALUES("5","5","دانلود World War Z PS4 - بازی جنگ جهانی زامبی برای پلی استیشن ","World War Z یک بازی ویدئویی در سبک اکشن، تیراندازی و به صورت دید اول شخص است که توسط شرکت Saber Interactive توسعه یافته و به وسیله Focus Home Interactive با همکاری MAD DOG GAMES در آوریل 2019 برای پلتفرم های پلی استیشن 4 و ایکس باکس وان منتشر شده است. بازی بر اساس فیلمی با همین نام ساخته شده است که در سال 2013 اکران شده بود.","<p>\n	در بازی همانند داستان فیلم بر اثر شیوع ویروسی مرگبار انسان ها تبدیل به زامبی های خطرناکی شده اند که دارای سرعتی بالا هستند و به شدت به افراد زنده حمله می کنند. داستان بازی در شهر های مسکو، توکیو، نیویورک و اورشلیم جریان دارد که به بهترین نحو ممکن طراحی شده اند. 4 شخصیت اصلی بازی دارای توانایی های مخصوص به خود و سلاح های منحصر به فردی می باشند که می توانید از هرکدام از آنها استفاده کرده و کنترل آنها را بدست بگیرید. گیم پلی بازی &quot;جنگ جهانی زامبی&quot; دارای حالت تک نفره و حالت مولتی پلیر آنلاین چهار نفره می باشد که هر قسمت دارای ویژگی های مخصوص به خود است. وجود انواح سلاح های ویرانگر برای از بین بردن زامبی ها با قابلیت ارتقاء یکی از ویژگی های بازی می باشد که می توانید با کمک دیگر شخصیت های درون بازی از این ویژگی به بهترین نحو ممکن استفاده نمایید. همچنین بازیکنان می&zwnj;توانند شخصیت و حالت مورد نظر خود را از بین کلاس&zwnj;ها و حالت&zwnj;های متنوع بازی انتخاب کنند و وارد بازی شوند. </p>\n","1","2019-04-20 22:28:13");
INSERT INTO products VALUES("6","9","دانلود SolidCAM 2019 SP1 x64 + Documents and Training Materials - نرم افزار طراحی و شبیه‌سازی صنعتی","SolidCAM یک نرم افزار استاندارد بوده كه به عنوان مهندسی CAM با نرم افزار SolidWorks در ارتباط می‌باشد. این نرم افزار مجموعه‌ای از بهترین كلاس‌های ساخت را در داخل SolidWorks فراهم می‌آورد و فرآیندهای فرزکاری 2.5 بعدی، فرزکاری 3 بعدی، ماشین‌كاری سرعت بالا (HSM)، فرزكاری‌های 4 و 5 محوره، شبیه‌سازی فرزكاری 5 محوره، تراش‌كاری، تراش فرزهای تا 5 محور و وایركات را پشتیبانی می‌نماید. این نرم افزار بر روی SolidWorks نسخه 2012 تا 2019 قابل نصب و استفاده می‌باشد. ","<p>\n	<b>قابلیت&zwnj;های کلیدی <a class=\"backlink\" href=\"https://p30download.com/fa/software/\">نرم افزار</a> SolidCAM:</b><br />\n	- مهندسی CAM درون نرم افزار SolidWorks<br />\n	- شبیه&zwnj;سازی کامل از قسمت&zwnj;های مختلف قالب، دستگاه برش و فرز<br />\n	- شبیه&zwnj;سازی فرزكاری 2.5 بعدی<br />\n	- شبیه&zwnj;سازی فرزكاری 3 بعدی<br />\n	- شبیه&zwnj;سازی ماشین كاری سرعت بالا (HSM)<br />\n	- شبیه&zwnj;سازی فرزكاری 4 و 5 محوره<br />\n	- قابل نصب بر روی SolidWorks نسخه 2012 تا 2019<br />\n	- و ...</p>\n<p>\n	<a class=\"gallery cboxElement\" href=\"https://img.p30download.com/software/screenshot/2018/12/1545231786_solidcam-2019-ss-1.jpg\" target=\"_blank\" title=\"SolidCAM Screenshot 1\"> </a></p>\n","1","2019-04-20 22:29:05");





CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_persian_ci NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1= active , 0= inactive',
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO roles VALUES("1","برنامه نویس سایت","1","2013-04-25 02:56:11");
INSERT INTO roles VALUES("2","کاربر عادی","1","2013-05-05 08:43:56");
INSERT INTO roles VALUES("4","مدیر کل سایت","1","2013-05-05 09:22:02");
INSERT INTO roles VALUES("5","بلاگر","0","2013-10-02 11:46:50");





CREATE TABLE `settings` (
  `site_title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `site_keywords` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `site_description` varchar(700) COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO settings VALUES("فن آوران پیشرو","فن آوران پیشرو","فن آوران پیشرو");





CREATE TABLE `sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `detail` varchar(500) COLLATE utf8_persian_ci NOT NULL,
  `url` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `image` varchar(200) COLLATE utf8_persian_ci DEFAULT NULL,
  `arrangment` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO sliders VALUES("1","بازار آهن بر مدار کاهش قیمت","بنابر تحلیل آهن پرایس از وضعیت بازار آهن، هفته گذشته بازار جهش قیمتی که برگرفته از فعالیت های سیاسی شکل گرفته علیه کشور و تروریسم خواندن سپاه پاسداران بود را پشت سرگذاشت. اتفاقی که به سرعت تمامی بازار های داخلی را تحت تاثیر خود قرار داد","https://ahanprice.com/Blog/%D8%A8%D8%A7%D8%B2%D8%A7%D8%B1-%D8%A2%D9%87%D9%86-%D8%A8%D8%B1-%D9%85%D8%AF%D8%A7%D8%B1-%DA%A9%D8%A7%D9%87%D8%B4-%D9%82%DB%8C%D9%85%D8%AA/Post/2711","7f18ef1adab058f3c68cbb7c4560f210.jpg","1","1","2019-04-16 16:16:49");
INSERT INTO sliders VALUES("2","تاثیر تورم داخلی بر بازار آهن ","به گزارش تحلیل گران آهن پرایس در اخبار بازار آهن، حاکی از این است تکرار فراز ها در روند سینوسی قیمت ها امری اجتناب ناپذیر است چرا که تجربه ثابت کرده است برای گذر از هر مرحله سینوسی کاهشی و افزایشی در حدود دوهفته زمان لازم است.موج افزایشی که در اواسط هفته گذشته به سرعت وارد فاز ثبات شده بود","https://ahanprice.com/Blog/%D8%AA%D8%A7%D8%AB%DB%8C%D8%B1-%D8%AA%D9%88%D8%B1%D9%85-%D8%AF%D8%A7%D8%AE%D9%84%DB%8C-%D8%A8%D8%B1-%D8%A8%D8%A7%D8%B2%D8%A7%D8%B1-%D8%A2%D9%87%D9%86-/Post/2708","f2b770d6a49df9453c3920f19a8f5469.jpg","2","1","2019-04-16 16:17:26");





CREATE TABLE `user_log_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `count_login` int(11) NOT NULL DEFAULT '1',
  `modified` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;






CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_persian_ci NOT NULL,
  `sex` tinyint(4) NOT NULL DEFAULT '-1',
  `age` smallint(6) NOT NULL,
  `user_name` varchar(200) COLLATE utf8_persian_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL COMMENT 'full url to image file',
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`,`user_name`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

INSERT INTO users VALUES("1","1","مجتبي پوراصغر","1","0","","cca908a919a6e26163db7282813429d6a6ec75fe","pourasghar2006@gmail.com","","1","2013-11-19 00:00:00","2013-08-01 09:12:38","2013-12-28 13:26:05");



